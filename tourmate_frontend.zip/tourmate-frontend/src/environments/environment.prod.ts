export const environment = {
  production: true,
  apiUrl: 'https://YOUR-PRODUCTION-API-URL',
  jwtPrefix: 'Bearer'
};
