export const environment = {
  production: false,
  apiUrl: 'http://localhost:3000',
  jwtPrefix: 'Bearer' // must match process.env.JWT_PREFIX on the backend .env
};
