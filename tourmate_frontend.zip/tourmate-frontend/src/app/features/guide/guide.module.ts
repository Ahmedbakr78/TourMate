import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from 'src/app/shared/shared.module';
import { AuthGuard } from 'src/app/core/guards/auth.guard';
import { GuideOnboardingComponent } from './guide-onboarding/guide-onboarding.component';
import { GuideListComponent } from './guide-list/guide-list.component';

const routes: Routes = [
  { path: '', component: GuideListComponent },
  { path: 'become-a-guide', component: GuideOnboardingComponent, canActivate: [AuthGuard] }
];

@NgModule({
  declarations: [GuideOnboardingComponent, GuideListComponent],
  imports: [SharedModule, RouterModule.forChild(routes)]
})
export class GuideModule { }
