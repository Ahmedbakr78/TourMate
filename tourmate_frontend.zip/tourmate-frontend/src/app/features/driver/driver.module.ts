import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from 'src/app/shared/shared.module';
import { AuthGuard } from 'src/app/core/guards/auth.guard';
import { DriverOnboardingComponent } from './driver-onboarding/driver-onboarding.component';
import { DriverListComponent } from './driver-list/driver-list.component';

const routes: Routes = [
  { path: '', component: DriverListComponent },
  { path: 'become-a-driver', component: DriverOnboardingComponent, canActivate: [AuthGuard] }
];

@NgModule({
  declarations: [DriverOnboardingComponent, DriverListComponent],
  imports: [SharedModule, RouterModule.forChild(routes)]
})
export class DriverModule { }
